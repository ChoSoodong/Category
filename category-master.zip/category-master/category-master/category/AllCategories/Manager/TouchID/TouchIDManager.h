





#import <Foundation/Foundation.h>

extern NSInteger const kTouchIDErrorUnvailable;
extern NSInteger const kTouchIDErrorUnAllow;


@interface TouchIDManager : NSObject

typedef BOOL(^TouchIDAllowBlock)(TouchIDManager *);
typedef void(^PassSuccessBlock)(TouchIDManager *);
typedef void(^PassFailBlock)(TouchIDManager *,NSError *);

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
+ (instancetype)new UNAVAILABLE_ATTRIBUTE;

+ (instancetype)sharedManager ;

- (void)tryToPass;

@property (assign,nonatomic,readonly) BOOL isTouchIDAvailable;
@property (assign,nonatomic,readonly) BOOL isTouchIDAllowed;

@property (nonatomic,strong) NSString *alertDescription ;

@property (nonatomic,copy) TouchIDAllowBlock touchIDAllowBlock ;
@property (nonatomic,copy) PassSuccessBlock passSuccessBlock ;
@property (nonatomic,copy) PassFailBlock passFailBlock ;

@end
