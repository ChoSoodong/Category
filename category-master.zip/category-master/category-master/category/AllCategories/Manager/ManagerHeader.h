





#ifndef ManagerHeader_h
#define ManagerHeader_h

#import "AuthorizationManager.h"
#import "AppVersionManager.h"

#import "TouchIDManager.h"

#import "AppPurchaseManager.h"
#import "BluetoothManager.h"
#import "DownloadManager.h"
#import "SoundManager.h"


#import "PushNotificationManager.h"


#endif /* ManagerHeader_h */
