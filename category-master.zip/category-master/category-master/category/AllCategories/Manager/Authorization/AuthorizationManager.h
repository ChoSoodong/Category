







#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger,AuthorizationType) {
    AuthorizationTypePhoto = 0,
    AuthorizationTypeCamera,
    AuthorizationTypeMedia,
    AuthorizationTypeMicrophone,
    AuthorizationTypeLocation,
    AuthorizationTypeBluetooth,
    AuthorizationTypePushNotification,
    AuthorizationTypeSpeech,
    AuthorizationTypeEvent,
    AuthorizationTypeContact,
    AuthorizationTypeReminder,
    AuthorizationTypeHealth,
};

typedef NS_ENUM(NSUInteger,AuthorizationStatus) {
    AuthorizationStatusAuthorized = 0,
    AuthorizationStatusDenied,
    AuthorizationStatusNotDetermined,
    AuthorizationStatusRestricted,
    AuthorizationStatusLocationAlways,
    AuthorizationStatusLocationWhenInUse,
    AuthorizationStatusUnkonwn,
};


@interface AuthorizationManager : NSObject


/// 单例对象
+ (instancetype)sharedManager ;

- (void)requestAuthorizationType:(AuthorizationType)type
                     completion:(void(^)(BOOL response,AuthorizationStatus status))completion;


@end
