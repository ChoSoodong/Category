






#import "AuthorizationManager.h"
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>
#import <EventKit/EventKit.h>
#import <Contacts/Contacts.h>
#import <Speech/Speech.h>
#import <HealthKit/HealthKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <UserNotifications/UserNotifications.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreLocation/CoreLocation.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

@implementation AuthorizationManager

/// 单例
+ (instancetype)sharedManager{
    static AuthorizationManager *manager = nil ;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc]init] ;
    });
    return manager ;
}

- (void)requestAuthorizationType:(AuthorizationType)type completion:(void (^)(BOOL, AuthorizationStatus))completion{
    switch (type) {
        case AuthorizationTypePhoto:
            [self requestAuthorizationTypePhotoCompletion:completion];
            break;
        case AuthorizationTypeCamera:
            [self requestAuthorizationTypeCameraCompletion:completion];
            break;
        case AuthorizationTypeMedia:
            [self requestAuthorizationTypeMediaCompletion:completion];
            break;
        case AuthorizationTypeMicrophone:
            [self requestAuthorizationTypeMicrophoneCompletion:completion];
            break;
        case AuthorizationTypeLocation:
            [self requestAuthorizationTypeLocationCompletion:completion];
            break;
        case AuthorizationTypeBluetooth:
            [self requestAuthorizationTypeBluetoothCompletion:completion];
            break;
        case AuthorizationTypePushNotification:
            [self requestAuthorizationTypePushNotificationCompletion:completion];
            break;
        case AuthorizationTypeSpeech:
            [self requestAuthorizationTypeSpeechCompletion:completion];
            break;
        case AuthorizationTypeEvent:
            [self requestAuthorizationTypeEventCompletion:completion];
            break;
        case AuthorizationTypeContact:
            [self requestAuthorizationType:AuthorizationTypeContact completion:completion];
            break;
        case AuthorizationTypeReminder:
            [self requestAuthorizationTypeReminderCompletion:completion];
            break;
        case AuthorizationTypeHealth:
            [self requestAuthorizationTypeHealthCompletion:completion];
            break;
        default:
            break;
    }
}

- (void)requestAuthorizationTypePhotoCompletion:(void (^)(BOOL, AuthorizationStatus))completion{
    [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
        if (!completion) return;
        if (status == PHAuthorizationStatusDenied) {
            completion(NO,AuthorizationStatusDenied);
        } else if (status == PHAuthorizationStatusNotDetermined) {
            completion(NO,AuthorizationStatusNotDetermined);
        } else if (status == PHAuthorizationStatusRestricted) {
            completion(NO,AuthorizationStatusRestricted);
        } else if (status == PHAuthorizationStatusAuthorized) {
            completion(YES,AuthorizationStatusAuthorized);
        }
    }];
}

- (void)requestAuthorizationTypeCameraCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (!completion) return;
        if (granted) {
            completion(YES,AuthorizationStatusAuthorized);
        } else {
            if (status == AVAuthorizationStatusDenied) {
                completion(NO,AuthorizationStatusDenied);
            } else if (status == AVAuthorizationStatusNotDetermined) {
                completion(NO,AuthorizationStatusNotDetermined);
            } else if (status == AVAuthorizationStatusRestricted) {
                completion(NO,AuthorizationStatusRestricted);
            }
        }
    }];
}

- (void)requestAuthorizationTypeMediaCompletion:(void (^)(BOOL, AuthorizationStatus))completion{
    [MPMediaLibrary requestAuthorization:^(MPMediaLibraryAuthorizationStatus status) {
        if (!completion) return;
        if (status == MPMediaLibraryAuthorizationStatusDenied) {
            completion(NO,AuthorizationStatusDenied);
        } else if (status == MPMediaLibraryAuthorizationStatusNotDetermined) {
            completion(NO,AuthorizationStatusNotDetermined);
        } else if (status == MPMediaLibraryAuthorizationStatusRestricted) {
            completion(NO,AuthorizationStatusRestricted);
        } else if (status == MPMediaLibraryAuthorizationStatusAuthorized) {
            completion(YES,AuthorizationStatusAuthorized);
        }
    }];
}

- (void)requestAuthorizationTypeMicrophoneCompletion:(void (^)(BOOL, AuthorizationStatus))completion{
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
        if (!completion) return;
        if (granted) {
            completion(YES,AuthorizationStatusAuthorized);
        } else {
            if (status == AVAuthorizationStatusDenied) {
                completion(NO,AuthorizationStatusDenied);
            } else if (status == AVAuthorizationStatusNotDetermined) {
                completion(NO,AuthorizationStatusNotDetermined);
            } else if (status == AVAuthorizationStatusRestricted) {
                completion(NO,AuthorizationStatusRestricted);
            }
        }
    }];
}

- (void)requestAuthorizationTypeLocationCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    if ([CLLocationManager locationServicesEnabled]) {
        CLLocationManager *locationManager = [[CLLocationManager alloc]init];
        [locationManager requestAlwaysAuthorization];
        [locationManager requestWhenInUseAuthorization];
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
        locationManager.distanceFilter = 10;
        [locationManager startUpdatingLocation];
    }
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    if (!completion) return;
    if (status == kCLAuthorizationStatusAuthorizedAlways) {
        completion(YES,AuthorizationStatusLocationAlways);
    } else if (status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        completion(YES,AuthorizationStatusLocationWhenInUse);
    } else if (status == kCLAuthorizationStatusDenied) {
        completion(NO,AuthorizationStatusDenied);
    } else if (status == kCLAuthorizationStatusNotDetermined) {
        completion(NO,AuthorizationStatusNotDetermined);
    } else if (status == kCLAuthorizationStatusRestricted) {
        completion(NO,AuthorizationStatusRestricted);
    }
}

- (void)requestAuthorizationTypeBluetoothCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    CBCentralManager *centralManager = [[CBCentralManager alloc] init];
    CBManagerState state = [centralManager state];
    if (!completion) return;
    if (state == CBManagerStateUnsupported || state == CBManagerStateUnauthorized || state == CBManagerStateUnknown) {
        completion(NO,AuthorizationStatusDenied);
    } else {
        completion(YES,AuthorizationStatusAuthorized);
    }
}

- (void)requestAuthorizationTypePushNotificationCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    if ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 10.0) {
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        UNAuthorizationOptions types=UNAuthorizationOptionBadge|UNAuthorizationOptionAlert|UNAuthorizationOptionSound;
        [center requestAuthorizationWithOptions:types completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (!completion) return;
            if (granted) {
                [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
                }];
                completion(YES,AuthorizationStatusAuthorized);
            } else {
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString] options:@{UIApplicationOpenURLOptionUniversalLinksOnly:@""} completionHandler:^(BOOL success) { }];
            }
        }];
    }else if ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0){
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeSound | UIUserNotificationTypeBadge categories:nil]];
    }
}

- (void)requestAuthorizationTypeSpeechCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
        if (!completion) return;
        if (status == SFSpeechRecognizerAuthorizationStatusDenied) {
            completion(NO,AuthorizationStatusDenied);
        } else if (status == SFSpeechRecognizerAuthorizationStatusNotDetermined) {
            completion(NO,AuthorizationStatusNotDetermined);
        } else if (status == SFSpeechRecognizerAuthorizationStatusRestricted) {
            completion(NO,AuthorizationStatusRestricted);
        } else if (status == SFSpeechRecognizerAuthorizationStatusAuthorized) {
            completion(YES,AuthorizationStatusAuthorized);
        }
    }];
}

- (void)requestAuthorizationTypeEventCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    EKEventStore *store = [[EKEventStore alloc]init];
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError * _Nullable error) {
        if (!completion) return;
        EKAuthorizationStatus status = [EKEventStore  authorizationStatusForEntityType:EKEntityTypeEvent];
        if (granted) {
            completion(YES,AuthorizationStatusAuthorized);
        } else {
            if (status == EKAuthorizationStatusDenied) {
                completion(NO,AuthorizationStatusDenied);
            } else if (status == EKAuthorizationStatusNotDetermined) {
                completion(NO,AuthorizationStatusNotDetermined);
            } else if (status == EKAuthorizationStatusRestricted) {
                completion(NO,AuthorizationStatusRestricted);
            }
        }
    }];
}

- (void)requestAuthorizationTypeContactCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    CNContactStore *contactStore = [[CNContactStore alloc] init];
    [contactStore requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (!completion) return;
        CNAuthorizationStatus status = [CNContactStore authorizationStatusForEntityType:CNEntityTypeContacts];
        if (granted) {
            completion(YES,AuthorizationStatusAuthorized);
        } else {
            if (status == CNAuthorizationStatusDenied) {
                completion(NO,AuthorizationStatusDenied);
            }else if (status == CNAuthorizationStatusRestricted){
                completion(NO,AuthorizationStatusNotDetermined);
            }else if (status == CNAuthorizationStatusNotDetermined){
                completion(NO,AuthorizationStatusRestricted);
            }
        }
    }];
}

- (void)requestAuthorizationTypeReminderCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    EKEventStore *eventStore = [[EKEventStore alloc]init];
    [eventStore requestAccessToEntityType:EKEntityTypeReminder completion:^(BOOL granted, NSError * _Nullable error) {
        if (!completion) return;
        EKAuthorizationStatus status = [EKEventStore  authorizationStatusForEntityType:EKEntityTypeEvent];
        if (granted) {
            completion(YES,AuthorizationStatusAuthorized);
        } else {
            if (status == EKAuthorizationStatusDenied) {
                completion(NO,AuthorizationStatusDenied);
            }else if (status == EKAuthorizationStatusNotDetermined){
                completion(NO,AuthorizationStatusNotDetermined);
            }else if (status == EKAuthorizationStatusRestricted){
                completion(NO,AuthorizationStatusRestricted);
            }
        }
    }];
}

- (void)requestAuthorizationTypeHealthCompletion:(void (^)(BOOL, AuthorizationStatus))completion {
    if ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0) {
        if (![HKHealthStore isHealthDataAvailable]) {
            NSAssert([HKHealthStore isHealthDataAvailable],@"Device not support HealthKit");
        }else{
            HKHealthStore *store = [[HKHealthStore alloc] init];
            NSSet *readObjectTypes = [self readObjectTypes];
            NSSet *writeObjectTypes = [self writeObjectTypes];
            [store requestAuthorizationToShareTypes:writeObjectTypes readTypes:readObjectTypes completion:^(BOOL success, NSError * _Nullable error) {
                if (!completion) return;
                if (success == YES) {
                    completion(YES,AuthorizationStatusAuthorized);
                }else{
                    completion(NO,AuthorizationStatusUnkonwn);
                }
            }];
        }
    }else{
        NSAssert([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0, @"iOS8 below systems are not currently supported");
    }
}


-(NSSet *)readObjectTypes{
    HKQuantityType *StepCount = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKQuantityType *DistanceWalkingRunning= [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning];
    HKObjectType *FlightsClimbed = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed];
    
    return [NSSet setWithObjects:StepCount,DistanceWalkingRunning,FlightsClimbed, nil];
}
-(NSSet *)writeObjectTypes{
    HKQuantityType *StepCount = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKQuantityType *DistanceWalkingRunning= [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning];
    HKObjectType *FlightsClimbed = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed];
    
    return [NSSet setWithObjects:StepCount,DistanceWalkingRunning,FlightsClimbed, nil];
}

@end

#pragma clang diagnostic pop
