//
//  UIImageView+Addition.m
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "UIImageView+Addition.h"

@implementation UIImageView (Addition)

+(instancetype)imageViewWithFrame:(CGRect)frame imageName:(NSString *)imageName contentMode:(UIViewContentMode)contentMode{
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    imageView.frame  = frame;
    imageView.contentMode = contentMode;
    return imageView;
}

/** 创建UIImageView */
+(instancetype)imageViewWithFrame:(CGRect)frame
                        imageName:(NSString *)imageName{
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    imageView.frame  = frame;
    return imageView;
}

@end
