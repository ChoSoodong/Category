








#import <UIKit/UIKit.h>

@interface UIView (Frame)

@property (nonatomic, assign) CGPoint origin;

@property (nonatomic) CGFloat left;        ///<  frame.origin.x.
@property (nonatomic) CGFloat top;         ///<  frame.origin.y
@property (nonatomic) CGFloat right;       ///<  frame.origin.x + frame.size.width
@property (nonatomic) CGFloat bottom;      ///<  frame.origin.y + frame.size.height
@property (nonatomic, assign)CGFloat width;
@property (nonatomic, assign)CGFloat height;
@property (nonatomic, assign)CGFloat centerX;
@property (nonatomic, assign)CGFloat centerY;
@property (nonatomic, assign)CGSize size;


/**
 *  水平居中
 */
- (void)alignHorizontal;
/**
 *  垂直居中
 */
- (void)alignVertical;
/**
 *  判断是否显示在主窗口上面
 *
 *  @return 是否
 */
- (BOOL)isShowOnWindow;



/**
 删除所有子控件
 */
- (void)removeAllSubViews;

@end
