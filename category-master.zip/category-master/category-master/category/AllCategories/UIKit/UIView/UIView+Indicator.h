






#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Indicator)

/// 显示菊花
- (void)showIndicator;

/// 隐藏菊花
- (void)hideIndicator;

@end

NS_ASSUME_NONNULL_END
