





#import "UIView+Indicator.h"
#import <objc/runtime.h>

static NSString *const IndicatorViewKey = @"indicatorView";

@implementation UIView (Indicator)

- (void)showIndicator{
    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    indicator.center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
    [indicator startAnimating];
    [self addSubview:indicator];
}

- (void)hideIndicator{

    UIActivityIndicatorView *indicator = (UIActivityIndicatorView *)objc_getAssociatedObject(self, &IndicatorViewKey);

    [indicator removeFromSuperview];
    
}



@end
