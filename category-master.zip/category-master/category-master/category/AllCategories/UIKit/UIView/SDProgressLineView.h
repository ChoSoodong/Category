//
//  SDProgressLineView.h
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SDProgressLineView : UIView


/**
 *  进度条高度
 */
@property (nonatomic, assign) CGFloat progressHeight;

/**
 *  进度最大值  maxValue
 */
@property (nonatomic, assign) CGFloat progressMaxValue;


/**
 *  进度值  value
 */
@property (nonatomic, assign) CGFloat progressValue;

/**
 *   动态进度条颜色  Dynamic progress
 */
@property (nonatomic, strong) UIColor *trackTintColor;

/**
 *  静态背景颜色    static progress 默认可以storyboard定义
 */
@property (nonatomic, strong) UIColor *progressTintColor;

@property (nonatomic, assign) CGFloat cornerRadius;


@end

