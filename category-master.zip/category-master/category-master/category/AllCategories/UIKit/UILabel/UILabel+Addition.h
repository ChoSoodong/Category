//
//  UILabel+Addition.h
//
//
//
//
//

#import <UIKit/UIKit.h>

@interface UILabel (Addition)

/**
  创建label

 @param color 文字颜色
 @param fontSize 字体大小
 @param lines 行数
 @param text label文字
 @return label
 */
+ (instancetype)labelWithTextColor:(UIColor *)color andTextFontSize:(CGFloat)fontSize andNumblerOfLines:(NSInteger)lines andText:(NSString *)text ;

/**
 创建label
 
 @param fontSize 加粗字体
 @param color 字体颜色
 @param lines 行数
 @param text 文字
 @return label
 */
+ (instancetype)labelWithBoldFontSize:(CGFloat)fontSize textColor:(UIColor *)color numblerOfLines:(NSInteger)lines text:(NSString *)text;

/**
 创建Label 带frame

 @param frame frame
 @param color 文字颜色
 @param fontSize 字体大小
 @param lines 行数
 @param text label文字
 @return label
 */
+ (instancetype)labelWithFrame:(CGRect)frame TextColor:(UIColor *)color andTextFontSize:(CGFloat)fontSize andNumblerOfLines:(NSInteger)lines andText:(NSString *)text;

@end
