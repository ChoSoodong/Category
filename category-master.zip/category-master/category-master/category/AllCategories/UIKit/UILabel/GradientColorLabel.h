//
//  GradientColorLabel.h
//  TasteFresh
//
//  Created by ZHAO on 2018/3/2.
//  Copyright © 2018年 XiaLanTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GradientColorLabel : UIView

@property (nonatomic, strong, readonly) UILabel *textLabel;
@property (nonatomic, strong, readonly) UILabel *maskLabel;

- (void)setFont:(UIFont *)font;

- (void)setText:(NSString *)text;

- (void)setTextAlignment:(NSTextAlignment)textAlignment;


- (void)startAnimation;

- (void)stopAnimation;

@end
