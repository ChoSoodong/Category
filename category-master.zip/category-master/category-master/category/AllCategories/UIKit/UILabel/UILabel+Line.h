//
//  UILabel+Line.h
//  KoreanPetApp
//
//  Created by xialan on 2018/11/5.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,LinePositionType){
    LinePositionMiddle = 0, //中划线
    LinePositionBottom      //下划线
};


@interface UILabel (Line)

-(instancetype)setDeleteLinePosition:(LinePositionType)positionType;

@end


