//
//  UIButton+Addition.m
//  TryToHARAM
//
//  Created by xialan on 2018/10/19.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import "UIButton+Addition.h"

@implementation UIButton (Addition)

+(instancetype)buttonWithHighlightedTitle:(NSString *)hl_title highlightColor:(UIColor *)hl_color highlightImageName:(NSString *)hl_imageName highlightBackgroundImageName:(NSString *)hl_bgImageName normalTitle:(NSString *)nor_title normalColor:(UIColor *)nor_color normalImageName:(NSString *)nor_imageName normalBackgroundImageName:(NSString *)nor_bgImageName font:(CGFloat)font {
    
    UIButton *button = [[self alloc] init];
    //各个状态标题
    [button setTitle:nor_title forState:UIControlStateNormal];
    [button setTitle:hl_title forState:UIControlStateHighlighted];
    
    //各个状态文字颜色
    [button setTitleColor:nor_color forState:UIControlStateNormal];
    [button setTitleColor:hl_color forState:UIControlStateHighlighted];
    
    //图片
    [button setImage:[UIImage imageNamed:nor_imageName] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:hl_imageName] forState:UIControlStateHighlighted];
    
    //字体
    button.titleLabel.font = [UIFont systemFontOfSize:font];
    
    //背景图片
    [button setBackgroundImage:[UIImage imageNamed:nor_bgImageName] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:hl_bgImageName] forState:UIControlStateHighlighted];
    
    return button;
}


+(instancetype)buttonWithSelectedTitle:(NSString *)sel_title selectedColor:(UIColor *)sel_color selectedImageName:(NSString *)sel_imageName selectedBackgroundImageName:(NSString *)sel_bgImageName normalTitle:(NSString *)nor_title normalColor:(UIColor *)nor_color normalImageName:(NSString *)nor_imageName normalBackgroundImageName:(NSString *)nor_bgImageName font:(CGFloat)font {
    
    UIButton *button = [[self alloc] init];
    //各个状态标题
    [button setTitle:nor_title forState:UIControlStateNormal];
    [button setTitle:sel_title forState:UIControlStateSelected];
    
    //各个状态文字颜色
    [button setTitleColor:nor_color forState:UIControlStateNormal];
    [button setTitleColor:sel_color forState:UIControlStateSelected];
    
    //图片
    if (![nor_imageName isEqualToString:@""] && nor_imageName != nil) {
        [button setImage:[UIImage imageNamed:nor_imageName] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:sel_imageName] forState:UIControlStateSelected];
    }
    
    
    
    //字体
    button.titleLabel.font = [UIFont systemFontOfSize:font];
    
    //背景图片
    if (![nor_bgImageName isEqualToString:@""] && nor_bgImageName != nil) {
        [button setBackgroundImage:[UIImage imageNamed:nor_bgImageName] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:sel_bgImageName] forState:UIControlStateSelected];
    }

    return button;
}


@end
