//
//  ScrollTopButton.h
//  AlphaPay
//
//  Created by xialan on 2019/2/28.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScrollTopButton : UIButton

/**出现的距离*/
@property(nonatomic, assign)CGFloat distanceWhenShow;

/**初始化*/
- (instancetype)initWithScrollView:(UIScrollView *)scrollView;

@end

NS_ASSUME_NONNULL_END
