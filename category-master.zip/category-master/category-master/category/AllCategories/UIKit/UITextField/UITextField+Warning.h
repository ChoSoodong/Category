//
//  UITextField+Warning.h
//
//
//  Created by ZHAO on 2018/10/11.
//  
//

#import <UIKit/UIKit.h>

@interface UITextField (Warning)


/**
 显示闪烁的警示框
 */
- (void)showWarning;


@end
