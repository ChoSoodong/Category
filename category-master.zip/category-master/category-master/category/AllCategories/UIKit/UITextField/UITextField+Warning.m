//
//  UITextField+Warning.m
//  
//
//  Created by ZHAO on 2018/10/11.
//
//

#import "UITextField+Warning.h"

@implementation UITextField (Warning)


- (void)showWarning {
    
    // 设置layer相关属性
    CAShapeLayer *warnLayer = [CAShapeLayer layer];
    // 大小和文本框一致
    warnLayer.frame = self.bounds;
    // 画线 非圆角
    warnLayer.path = [UIBezierPath bezierPathWithRoundedRect:warnLayer.bounds cornerRadius:0].CGPath;
    // 线宽
    warnLayer.lineWidth = 6. / [[UIScreen mainScreen] scale];
    // 设置为实线
    warnLayer.lineDashPattern = nil;
    // 填充颜色透明色
    warnLayer.fillColor = [UIColor clearColor].CGColor;
    // 边框颜色为红色
    warnLayer.strokeColor = [UIColor redColor].CGColor;
    [self.layer addSublayer:warnLayer];
    
    
    
    // 透明度变化
    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.fromValue = [NSNumber numberWithFloat:1.0];
    opacityAnimation.toValue = [NSNumber numberWithFloat:0.0];
    opacityAnimation.repeatCount = 5;
    opacityAnimation.repeatDuration = 2;
    opacityAnimation.autoreverses = YES;
    [warnLayer addAnimation:opacityAnimation forKey:@"opacity"];
    
    // 2秒后移除动画
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 2秒后异步执行这里的代码...
        // 移除动画
        [warnLayer removeFromSuperlayer];
    });
}


@end
