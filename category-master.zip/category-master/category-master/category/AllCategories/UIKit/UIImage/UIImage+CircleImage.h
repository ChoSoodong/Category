//
//  UIImage+CircleImage.h
//  Finance
//
//  Created by ZHAO on 2018/9/28.
//  Copyright © 2018年 HaramElectronic. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^completion)(UIImage *completeImage);

@interface UIImage (CircleImage)

/**
 将image转为圆形image 需在子线程中执行
 */
- (instancetype)circleImage;


/**
 在子线程切圆角, block 返回 圆形图片

 @param completion 完成图片
 */
-(void)circleImageWithCompletion:(completion)completion;


/**
 传入图片名称转为圆形image

 @param name 图片名称
 @return 圆形image
 */
+ (instancetype)circleImageNamed:(NSString *)name;



/**
 将image转为带圆角的image

 @param radius 圆角半径 0.5是圆形 小于0.5 是带圆角的矩形 大于0.5是椭圆
 @return 带圆角的image
 */
- (instancetype)drawCornerRadiusWithRadius:(CGFloat)radius;
+ (instancetype)drawCornerRadiusWithImageNamed:(NSString *)name radius:(CGFloat)radius;

/**
 子线程中切圆角

 @param radius 圆角半径 0.5是圆形 小于0.5 是带圆角的矩形 大于0.5是椭圆
 @param completion 完成图片
 */
-(void)drawCornerRadiusWithRadius:(CGFloat)radius completion:(completion)completion;
@end
