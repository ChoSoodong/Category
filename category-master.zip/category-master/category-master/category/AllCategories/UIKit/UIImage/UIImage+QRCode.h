//
//  UIImage+QRCode.h
//  Finance
//
//  Created by ZHAO on 2018/8/21.
//  Copyright © 2018年 HaramElectronic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (QRCode)

/**
 生成中间带logo的二维码

 @param text 二维码中的文字
 @param logoImage 中间图片
 @return 二维码
 */
+(UIImage *)imageWithQRCodeText:(NSString *)text logoImage:(UIImage *)logoImage;

@end
