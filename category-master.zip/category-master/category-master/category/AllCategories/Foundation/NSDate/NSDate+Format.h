//
//  NSDate+Format.h
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDate (Format)

/**
 【 格式化规则 】
if(同一年) {
    if(同一月) {
        if(同一天) {
             < 1分钟：               刚刚
             >= 1分钟 < 1小时：       xx分钟前
             >= 1小时 < 24小时：      xx小时前
        } else if(昨天) {
             昨天 HH:mm
        } else if(前天) {
             前天 HH:mm
        } else {
             MM-dd HH:mm
        }
 } else {
        MM-dd HH:mm
 }
} else {
      yyyy-MM-dd HH:mm
}
 */
+ (NSString *)timeLineStringWithTimeInterval:(NSTimeInterval)secs;
+ (NSString *)timeLineStringWithDate:(NSDate *)date;


@end


