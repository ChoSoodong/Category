//
//  NSString+Image.m
//  Finance
//
//  Created by xialan on 2018/12/3.
//  Copyright © 2018 HaramElectronic. All rights reserved.
//

#import "NSString+Image.h"

@implementation NSString (Image)

-(void)URLStringToImageCompletion:(completion)completion{
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // 获取网络图片地址
        NSURL *url = [NSURL URLWithString:self];
        // 获取网络图片二进制数据
        NSData *data = [NSData dataWithContentsOfURL:url];
        // 获取图片对象
        UIImage *image = [UIImage imageWithData:data];
        
        if (image != nil) {
            // 图片下载完成之后,回到主线程更新UI
            dispatch_async(dispatch_get_main_queue(), ^{
                
                completion ? completion(image) : nil;
            });
        }

    });
 
}

+(void)URLStringToImageWithUrlString:(NSString *)url completion:(completion)completion{
    
    [url URLStringToImageCompletion:^(UIImage *image) {
        completion ? completion(image) : nil;
    }];
}

@end
