//
//  NSString+Image.h
//  Finance
//
//  Created by xialan on 2018/12/3.
//  Copyright © 2018 HaramElectronic. All rights reserved.
//

#import <Foundation/Foundation.h>

/**请求完成的Block*/
typedef void(^ completion)(UIImage *image);

@interface NSString (Image)


/**
 图片url字符串转为图片 , 异步加载

 @param completion 请求完成的图片
 */
-(void)URLStringToImageCompletion:(completion)completion;

+(void)URLStringToImageWithUrlString:(NSString *)url completion:(completion)completion;

@end


