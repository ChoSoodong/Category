







#import <Foundation/Foundation.h>

@interface NSString (AES)

///  加密方法
- (NSString *)encryptWithAESwithKey:(NSString *)key ivParameter:(NSString *)ivParameter;

/// 解密方法
- (NSString*)decryptWithAESwithKey:(NSString *)key ivParameter:(NSString *)ivParameter;


@end
