


#ifndef CategoryHeader_h
#define CategoryHeader_h

#import "FoundationHeader.h"
#import "UIKitHeader.h"
#import "Macros.h"
#import "ManagerHeader.h"
#import "QuartzCoreHeader.h"

#endif /* CategoryHeader_h */
