






#import <Foundation/Foundation.h>



@interface NSObject (Description)



@end


