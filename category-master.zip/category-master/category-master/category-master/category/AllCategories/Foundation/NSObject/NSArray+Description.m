






#import "NSArray+Description.h"

@implementation NSArray (Description)

- (NSString *)descriptionWithLocale:(id)locale indent:(NSUInteger)level
{
    NSMutableString *str = [NSMutableString stringWithString:@"(\n"];
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [str appendFormat:@"\t%@,\n", obj];
    }];
    [str appendString:@")"];
    return str;
}


@end
