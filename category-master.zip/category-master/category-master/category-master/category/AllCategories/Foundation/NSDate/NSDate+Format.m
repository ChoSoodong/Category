//
//  NSDate+Format.m
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "NSDate+Format.h"

@implementation NSDate (Format)

+ (NSString *)timeLineStringWithTimeInterval:(NSTimeInterval)secs
{
    return [self timeLineStringWithDate:[NSDate dateWithTimeIntervalSince1970:secs]];
}

+ (NSString *)timeLineStringWithDate:(NSDate *)date
{
    NSCalendar *clendar = [NSCalendar currentCalendar];
    NSUInteger unitFlags = NSCalendarUnitMinute | NSCalendarUnitHour | NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear;
    
    NSDateComponents *theDateComponents = [clendar components:unitFlags fromDate:date];
    NSDateComponents *nowComponents = [clendar components:unitFlags fromDate:[NSDate date]];
    
    NSString *format = nil;
    
    if ([theDateComponents year] == [nowComponents year]) {
        if ([theDateComponents month] == [nowComponents month]) {
            if ([theDateComponents day] == [nowComponents day]) {
                NSTimeInterval interval = fabs([date timeIntervalSinceNow]);
                if (interval < 60) {
                    return @"刚刚";
                } else if (interval < (60 * 60)) {
                    return [NSString stringWithFormat:@"%ld分钟前", ((long)interval)/60];
                } else {
                    return [NSString stringWithFormat:@"%ld小时前", ((long)interval)/(60 * 60)];
                }
            } else if ([theDateComponents day] == [nowComponents day] - 1) {
                format = @"昨天 HH:mm";
            } else if ([theDateComponents day] == [nowComponents day] - 2) {
                format = @"前天 HH:mm";
            } else {
                format = @"MM-dd HH:mm";
            }
        } else {
            format = @"MM-dd HH:mm";
        }
    } else {
        format = @"yyyy-MM-dd HH:mm";
    }
    
    static NSDateFormatter *dateFormatter = nil;
    if (!dateFormatter) {
        dateFormatter = [[NSDateFormatter alloc] init];
    }
    
    [dateFormatter setDateFormat:format];
    return [dateFormatter stringFromDate: date];
}



@end
