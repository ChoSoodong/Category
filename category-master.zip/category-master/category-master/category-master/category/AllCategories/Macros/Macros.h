



//

#ifndef Macros_h
#define Macros_h

#import "UtilsMacro.h"
#import "ShortcutsMacro.h"
#import "SharedInstanceMacro.h"
#import "MathMacro.h"
#import "LogMacro.h"
#import "DeviceMacro.h"
#import "ARCMacro.h"
#import "ColorMacro.h"


#endif /* Macros_h */
