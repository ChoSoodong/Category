



// 屏幕信息
#define IS_RETINA_SCREE                          (MAIN_SCREEN.scale > 1.0)
#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREEN_BOUNDS [[UIScreen mainScreen] bounds]

// 设备类型
#define IS_IPHONE         (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IPAD           (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

#define IS_IPHONE_4 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )480 ) < DBL_EPSILON )
#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )
//是否为5之前的小屏幕
#define IS_IPHONE_5_before (IS_IPHONE_4 || IS_IPHONE_5)

#define IS_IPHONE_6 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )667 ) < DBL_EPSILON )
#define IS_IPHONE_6PLUS ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )736 ) < DBL_EPSILON )
#define IS_IPHONE_X ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )812 ) < DBL_EPSILON )

//判断iPHoneXr
#define IS_IPHONE_Xr ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !IS_IPAD : NO)
//判断iPhoneXs
#define IS_IPHONE_Xs ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) && !IS_IPAD : NO)
//判断iPhoneXs Max
#define IS_IPHONE_Xs_Max ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !IS_IPAD : NO)

//判断全面屏
#define IS_IPHONE_X_ALL (IS_IPHONE_X || IS_IPHONE_Xr || IS_IPHONE_Xs || IS_IPHONE_Xs_Max)

// 设备尺寸信息
#define STATUS_BAR_HEIGHT [UIApplication sharedApplication].statusBarFrame.size.height


 //正常状态的值
 #define NAVIGATION_BAR_HEIGHT 44.0f
 #define NAVIGATION_HEIGHT ((IS_IPHONE_X==YES || IS_IPHONE_Xr ==YES || IS_IPHONE_Xs== YES || IS_IPHONE_Xs_Max== YES) ? 88.0 : 64.0)



#define TABBAR_HEIGHT                (IS_IPHONE_X_ALL ? 83.0 : 49.0)
#define SAFE_BOTTOM_MARGIN_V         (IS_IPHONE_X_ALL ? 34.f : 0.f)
#define SAFE_BOTTOM_MARGIN_H         (IS_IPHONE_X_ALL ? 21.f : 0.f)
#define SAFE_LEFTORRIGHT_MARGIN_H         (IS_IPHONE_X_ALL ? 44.f : 0.f)
#define SAFE_INSETS(view) ({UIEdgeInsets insets; if(@available(iOS 11.0, *)) {insets = view.safeAreaInsets;} else {insets = UIEdgeInsetsZero;} insets;})

//底部安全高度
#define BOTTOM_BAR_HEIGHT        (IS_IPHONE_X_ALL ? 34.0 : 0)
//内容高度
#define CONTENT_HEIGHT         (SCREEN_HEIGHT - NAVIGATION_HEIGHT-BOTTOM_BAR_HEIGHT)


//有些比较大的控件，产品会要求按照屏幕比例进行调整，小屏幕的显示的小一点，大屏幕的显示大一点，这个也是两个宏搞定
#define KScaleW(A) [UIScreen mainScreen].bounds.size.width * (A / 375.f)
#define KScaleH(A) [UIScreen mainScreen].bounds.size.height * (A / 667.0)
//解释一下为什么除的667和375，因为UI给的设计图示按照667 * 375的屏幕给的，如果你们的UI给的设计图是按照iPhone5s的尺寸设计的，分母就要换成568和320。

// 自适应字号
#define AdjustFont(A) [UIFont adjustFontSize:A]
// 设置自适应字体
#define Sys_AdjustFont(A) [UIFont systemFontOfSize:AdjustFont(A)]

// 设备信息
#define DEVICE_MODEL                                [CURRENT_DEVICE model]
#define DEVICE_LOCALIZED_MODEL                      [CURRENT_DEVICE localizedModel]
#define DEVICE_PLATFORM                             [CURRENT_DEVICE platform]
#define DEVICE_SYSTEM_NAME                          [CURRENT_DEVICE systemName]
#define DEVICE_SYSTEM_VERSION                       [CURRENT_DEVICE systemVersion]

// 系统版本
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)              ([[CURRENT_DEVICE systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_IS_IOS4_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"4.0")
#define SYSTEM_VERSION_IS_IOS5_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"5.0")
#define SYSTEM_VERSION_IS_IOS6_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0")
#define SYSTEM_VERSION_IS_IOS7_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")
#define SYSTEM_VERSION_IS_IOS8_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0")
#define SYSTEM_VERSION_IS_IOS9_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"9.0")
#define SYSTEM_VERSION_IS_IOS10_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"10.0")
#define SYSTEM_VERSION_IS_IOS11_OR_GREATER                     SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"11.0")




