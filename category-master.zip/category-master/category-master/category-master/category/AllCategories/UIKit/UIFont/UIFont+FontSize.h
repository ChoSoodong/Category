





#import <UIKit/UIKit.h>
#import <objc/runtime.h>

#define IPHONE5_INCREMENT 2
#define IPHONE6_INCREMENT 1
#define IPHONE6PLUS_INCREMENT 2
#define IS_IPHONEX_INCREMENT 3

// 让字体根据屏幕尺寸自适应大小

@interface UIFont (FontSize)


/// 自适应字体大小
+ (CGFloat)adjustFontSize:(CGFloat)fontsize;


@end


