








#import <UIKit/UIKit.h>

@interface UINavigationBar (Awesome)

- (void)setBackgroundColor:(UIColor *)backgroundColor;
- (void)setElementsAlpha:(CGFloat)alpha;
- (void)setTranslationY:(CGFloat)translationY;
- (void)reset;

@end
