






#import "UIViewController+PhotoSelection.h"
#import <objc/runtime.h>
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>
#import <AVFoundation/AVMediaFormat.h>
#import <AssetsLibrary/AssetsLibrary.h>

@implementation UIViewController (PhotoSelection)

static char UIB_PROPERTY_KEY;

#pragma mark - Getter and setter methods

- (void)setCompletionBlock:(void (^)(BOOL, UIImage *))completionBlock
{
    objc_setAssociatedObject(self, &UIB_PROPERTY_KEY, completionBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(BOOL, UIImage *))completionBlock
{
    return (void (^)(BOOL, UIImage *))objc_getAssociatedObject(self, &UIB_PROPERTY_KEY);
}

#pragma mark - Publick methods

- (void)selectPhotoWithPhotoType:(PhotoType)type allowsEditing:(BOOL)allowsEditing completionHandler:(void(^)(BOOL success, UIImage *image))completionHandler
{
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil
                                                                         message:nil
                                                                  preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", @"") style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        self.completionBlock(NO, nil);
    }]];
    
    if (type == PhotoTypeCamera) {
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"拍照", @"") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            if (![self checkCameraIsAvailable]) return ;
            
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                picker.delegate = self;
                picker.allowsEditing = allowsEditing;
                [self presentViewController:picker animated:YES completion:nil];
            }else{
                
                 NSLog(@"摄像头不可用");
            }
        }]];
        
    }else{
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"拍照", @"") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            if (![self checkCameraIsAvailable]) return ;
            
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                picker.delegate = self;
                picker.allowsEditing = allowsEditing;
                [self presentViewController:picker animated:YES completion:nil];
            }else{
                NSLog(@"摄像头不可用");
            }
        }]];
        
        [actionSheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"从手机相册选择", @"") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            if (![self checkLibraryIsAvailable]) return ;
            
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                UIImagePickerController *picker1 = [[UIImagePickerController alloc] init];
                picker1.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                picker1.delegate = self;
                picker1.allowsEditing = allowsEditing;
                [self presentViewController:picker1 animated:YES completion:nil];
            }
        }]];
    }
    
    self.completionBlock = completionHandler;
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate methods

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    self.completionBlock(NO, nil);
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage * selectedImage = (UIImage *) [info valueForKey:UIImagePickerControllerOriginalImage];
    self.completionBlock(YES, selectedImage);
}

#pragma mark - 检查相机 和 相册 是否打开

- (BOOL)checkCameraIsAvailable
{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (status == AVAuthorizationStatusDenied || status == AVAuthorizationStatusRestricted) {
        // 没有认证，提醒去认证
        [self alertStr:@"请您设置允许APP访问您的相机\n设置>隐私>相册"];
        return NO;
    } else {
        return YES;
    }
}

- (BOOL)checkLibraryIsAvailable
{
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusDenied || status == PHAuthorizationStatusRestricted) {
        [self alertStr:@"请您设置允许APP访问您的相机\n设置>隐私>相册"];
        return NO;
    } else {
        return YES;
    }
}

#pragma mark - private
- (void)alertStr:(NSString *)str{
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:str preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"设置" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        // 跳转到设置界面
        NSURL * url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        if([[UIApplication sharedApplication] canOpenURL:url]) {
            NSURL*url =[NSURL URLWithString:UIApplicationOpenSettingsURLString];
            [[UIApplication sharedApplication] openURL:url];
        }
        
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertC addAction:action1];
    [alertC addAction:action2];
    [self presentViewController:alertC animated:YES completion:nil];
}

@end
