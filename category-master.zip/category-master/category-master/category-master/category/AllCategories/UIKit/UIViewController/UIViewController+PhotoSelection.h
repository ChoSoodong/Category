





#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, PhotoType) {
    
    PhotoTypeCamera = 0,//只有相机
    PhotoTypeCameraAndLibrary ,//相机和相册
    
};


@interface UIViewController (PhotoSelection)
<UINavigationControllerDelegate,
UIImagePickerControllerDelegate>

@property (copy) void (^completionBlock)(BOOL, UIImage *);

- (void)selectPhotoWithPhotoType:(PhotoType)type allowsEditing:(BOOL)allowsEditing completionHandler:(void(^)(BOOL success, UIImage *image))completionHandler;

@end
