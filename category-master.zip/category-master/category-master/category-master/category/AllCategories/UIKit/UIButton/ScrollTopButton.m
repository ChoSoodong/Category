//
//  ScrollTopButton.m
//  AlphaPay
//
//  Created by xialan on 2019/2/28.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "ScrollTopButton.h"

#define STScreenWidth [UIScreen mainScreen].bounds.size.width
#define STScreenHeight [UIScreen mainScreen].bounds.size.height
#define STDefaultW 40

@implementation ScrollTopButton{
    
    __weak UIScrollView *_scrollView;
}

- (instancetype)initWithScrollView:(UIScrollView *)scrollView{
    
    if (self = [super init]) {
        [self setupWithScrollView:scrollView];
    }
    return self;
}

- (void)setupWithScrollView:(UIScrollView *)scrollView{
    
    _scrollView = scrollView;
    self.distanceWhenShow = self.distanceWhenShow ?:STScreenHeight;
    
    self.backgroundColor = [UIColor clearColor];
    [self setBackgroundImage:[UIImage imageNamed:@"back_to_top"] forState:UIControlStateNormal];
    self.frame = CGRectMake(STScreenWidth - STDefaultW - 10, STScreenHeight - 100, STDefaultW, STDefaultW);
    [self addTarget:self action:@selector(scrollToTopClick) forControlEvents:UIControlEventTouchUpInside];
    
    [scrollView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)scrollToTopClick{
    
    [_scrollView setContentOffset:CGPointZero animated:YES];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    
    CGPoint point = [change[@"new"] CGPointValue];
    if (point.y <= self.distanceWhenShow) {
        self.hidden = YES;
    }else{
        self.hidden = NO;
    }
}

- (void)dealloc{
    
    [_scrollView removeObserver:self forKeyPath:@"contentOffset"];
}

@end
