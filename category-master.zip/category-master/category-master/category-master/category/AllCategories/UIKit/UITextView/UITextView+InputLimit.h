








#import <UIKit/UIKit.h>

@interface UITextView (InputLimit)

@property (assign, nonatomic)  NSInteger maxLength;//if <=0, no limit

@end
