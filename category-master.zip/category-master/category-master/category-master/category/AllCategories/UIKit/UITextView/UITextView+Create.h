







#import <UIKit/UIKit.h>


@interface UITextView (Create)


/**
  快速创建 textView

 @param backgroundColor 背景色
 @param placeholderColor 占位文字颜色
 @param placeholder 占位文字
 @param font 字号
 @param maxLength 最大输入长度 小于等于0就是不限制
 @param editable 是否可以编辑
 @return textView
 */
+(instancetype)textViewWithBackgroundColor:(UIColor *)backgroundColor TextColor:(UIColor *)textColor text:(NSString *)text placeholderColor:(UIColor *)placeholderColor placeholder:(NSString *)placeholder font:(CGFloat)font maxLength:(NSInteger)maxLength editable:(BOOL)editable;

@end

