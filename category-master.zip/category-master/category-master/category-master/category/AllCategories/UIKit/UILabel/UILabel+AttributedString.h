//
//  UILabel+AttributedString.h
//  TasteFresh
//
//  Created by ZHAO on 2018/1/12.
//  Copyright © 2018年 XiaLanTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (AttributedString)

/**
 为UILabel首部设置图片标签
 
 @param text 文本
 @param images 图片数组
 @param span 图片间距
 */
-(void)setText:(NSString *)text frontImages:(NSArray<UIImage *> *)images imageSpan:(CGFloat)span;


/**
 小数点前后字体不一样大, 试用于商品价格
 
 @param Text 传入字符串
 @param frontFont 小数点前面的字体大小
 @param behindFont 小数点后面的字体大小
 @param textColor 字符串的颜色
 */
-(void)setText:(NSString *)Text frontFont:(CGFloat)frontFont behindFont:(CGFloat)behindFont textColor:(UIColor *)textColor;


@end
