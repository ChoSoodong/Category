








#import <UIKit/UIKit.h>

@interface UIView (Screenshot)


/**
 截图
 
 @return UIImage
 */
- (UIImage *_Nullable)screenshot;

/**
 从指定view截图
 
 @param view 指定view
 
 @return UIImage
 */
+ (UIImage *_Nullable)captureFromView:(UIView *)view;



//ScrollView截图 contentOffset
- (UIImage*_Nullable) screenshotForScrollViewWithContentOffset:(CGPoint)contentOffset;

//View按Rect截图
- (UIImage*_Nullable) screenshotInFrame:(CGRect)frame;

//整个view转成图片
- (UIImage*_Nullable) convertToImage;



/// 截取当前View为PDF
- (nullable NSData *)snapshotPDF;

@end
