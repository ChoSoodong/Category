//
//  UITextField+SDDelegate.h
//  AlphaPay
//
//  Created by xialan on 2019/2/18.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SDTextFieldDelegate<UITextFieldDelegate>

@optional
- (void)textFieldDidDeleteBackward:(UITextField *)textField;

@end

@interface UITextField (SDDelegate)

@property (weak, nonatomic) id<SDTextFieldDelegate> delegate;

@end
