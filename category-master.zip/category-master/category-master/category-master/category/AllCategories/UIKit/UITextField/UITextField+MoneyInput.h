







#import <UIKit/UIKit.h>

@interface UITextField (MoneyInput)

//是否只能输入金额默认为NO
@property (nonatomic, assign) IBInspectable BOOL isMoney;

@end
