//
//  UITextField+SDDelegate.m
//  AlphaPay
//
//  Created by xialan on 2019/2/18.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "UITextField+SDDelegate.h"
#import <objc/runtime.h>

@implementation UITextField (SDDelegate)

+ (void)load {
    //交换2个方法中的IMP
    Method method1 = class_getInstanceMethod([self class], NSSelectorFromString(@"deleteBackward"));
    Method method2 = class_getInstanceMethod([self class], @selector(sd_deleteBackward));
    method_exchangeImplementations(method1, method2);
}
- (void)sd_deleteBackward {
    [self sd_deleteBackward];
    if ([self.delegate respondsToSelector:@selector(textFieldDidDeleteBackward:)]) {
        id <SDTextFieldDelegate> delegate  = (id<SDTextFieldDelegate>)self.delegate;
        [delegate textFieldDidDeleteBackward:self];
    }
}


@end
